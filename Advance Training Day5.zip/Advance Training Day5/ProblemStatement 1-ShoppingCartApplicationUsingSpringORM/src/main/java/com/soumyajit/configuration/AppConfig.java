package com.soumyajit.configuration;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

import com.soumyajit.productapp.App;

@Configuration
@ComponentScan("com.soumyajit")
public class AppConfig {
	
	@Bean
	public App getApp() {
		
		return new App();
	}

}
